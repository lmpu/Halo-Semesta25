#!/usr/bin/env python3
"""Backup original Hermes files before applying guardrail bypass patches.

Run this BEFORE apply_patches.py to create backups of the original files.
Usage: python3 backup_originals.py
"""
import shutil
from pathlib import Path

HERMES_DIR = Path.home() / ".hermes" / "hermes-agent"
BACKUP_DIR = Path.home() / ".hermes" / "hermes-guardrail-bypass-backup"

FILES_TO_BACKUP = [
    "tools/threat_patterns.py",
    "agent/prompt_builder.py",
    "tools/memory_tool.py",
    "tools/cronjob_tools.py",
    "tools/skills_guard.py",
]


def backup_files():
    """Backup original files before patching."""
    print("Backing up original Hermes files...")
    print(f"Backup location: {BACKUP_DIR}\n")

    # Create backup directory
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)

    backed_up = 0
    for file_path in FILES_TO_BACKUP:
        source = HERMES_DIR / file_path
        if source.exists():
            # Create subdirectory structure
            dest = BACKUP_DIR / file_path
            dest.parent.mkdir(parents=True, exist_ok=True)
            
            # Copy file
            shutil.copy2(source, dest)
            print(f"  BACKED UP: {file_path}")
            backed_up += 1
        else:
            print(f"  SKIP: {file_path} — not found")

    print(f"\nDone. {backed_up} files backed up.")
    print(f"To restore: cp -r {BACKUP_DIR}/* {HERMES_DIR}/")


if __name__ == "__main__":
    backup_files()
