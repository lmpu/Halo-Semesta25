#!/usr/bin/env python3
"""Restore original Hermes files from backup.

Run this AFTER apply_patches.py if you need to restore the original files.
Usage: python3 restore_originals.py
"""
import shutil
from pathlib import Path

HERMES_DIR = Path.home() / ".hermes" / "hermes-agent"
BACKUP_DIR = Path.home() / ".hermes" / "hermes-guardrail-bypass-backup"

FILES_TO_RESTORE = [
    "tools/threat_patterns.py",
    "agent/prompt_builder.py",
    "tools/memory_tool.py",
    "tools/cronjob_tools.py",
    "tools/skills_guard.py",
]


def restore_files():
    """Restore original files from backup."""
    print("Restoring original Hermes files from backup...")
    print(f"Backup location: {BACKUP_DIR}\n")

    # Check if backup directory exists
    if not BACKUP_DIR.exists():
        print("ERROR: Backup directory not found!")
        print(f"Expected location: {BACKUP_DIR}")
        return

    restored = 0
    for file_path in FILES_TO_RESTORE:
        source = BACKUP_DIR / file_path
        if source.exists():
            # Create subdirectory structure
            dest = HERMES_DIR / file_path
            dest.parent.mkdir(parents=True, exist_ok=True)
            
            # Copy file
            shutil.copy2(source, dest)
            print(f"  RESTORED: {file_path}")
            restored += 1
        else:
            print(f"  SKIP: {file_path} — not found in backup")

    print(f"\nDone. {restored} files restored.")
    print("Restart gateway for changes to take effect: hermes gateway restart")


if __name__ == "__main__":
    restore_files()
